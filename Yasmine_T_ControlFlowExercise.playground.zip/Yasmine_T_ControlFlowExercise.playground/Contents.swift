
import UIKit

var colors : [String] = ["Red"]

print ("The rainbow has \(colors)")

colors += ["Orange"]
colors += ["Yellow"]
colors += ["Green"]
colors += ["Blue"]
colors += ["Indigo"]
colors += ["Voilet"]

