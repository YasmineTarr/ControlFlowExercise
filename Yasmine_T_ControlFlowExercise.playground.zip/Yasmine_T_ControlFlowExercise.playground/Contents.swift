
import UIKit

var colors : [String] = ["Red"]

print ("The rainbow has \(colors)")

colors += ["Orange"]
colors += ["Yellow"]
colors += ["Green"]
colors += ["Blue"]
colors += ["Indigo"]
colors += ["Voilet"]

var ROYGBIV : [String: String] = ["first":"Red", "second": "Orange"]
ROYGBIV ["third"] = "yellow"
ROYGBIV ["fourth"] = "green"
ROYGBIV ["fifth"] = "blue"
ROYGBIV ["sixth"] = "indigo"
ROYGBIV ["seventh"] = "violet"

                                  
print("The rainbow contains \(ROYGBIV.count) colors")
